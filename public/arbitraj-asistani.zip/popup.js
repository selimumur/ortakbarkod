document.addEventListener('DOMContentLoaded', () => {
    const btnSave = document.getElementById('btn-save');
    const statusDiv = document.getElementById('status');
    const pTitle = document.getElementById('p-title');
    const pPrice = document.getElementById('p-price');
    const pImage = document.getElementById('p-image');

    let currentProduct = null;
    // Default API URL (Will need to be configured if hosted elsewhere, but fixed for now)
    const API_URL = 'https://ortakbarkod.vercel.app/api/arbitrage/watchlist';
    // const API_URL = 'http://localhost:3000/api/arbitrage/watchlist'; // For Local Dev

    // 1. Get Active Tab and Send Message to Content Script
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "GET_DETAILS" }, function (response) {
            if (response) {
                currentProduct = response;
                pTitle.value = response.title || '';
                pPrice.value = response.price || 0;
                pImage.src = response.image || '';
            } else {
                statusDiv.innerText = "Ürün bilgisi çekilemedi. Sayfayı yenileyip tekrar deneyin.";
                statusDiv.className = "status-msg text-error";
                btnSave.disabled = true;
            }
        });
    });

    // 2. Handle Save
    btnSave.addEventListener('click', async () => {
        if (!currentProduct) return;

        btnSave.disabled = true;
        btnSave.innerText = "Kaydediliyor...";
        statusDiv.innerText = "";

        // Update with edited values
        const payload = {
            product_name: pTitle.value,
            current_price: parseFloat(pPrice.value),
            image_url: pImage.src,
            product_url: currentProduct.url,
            market_name: currentProduct.market,
            currency: 'TRY', // Assume TRY for TR sites
            stock_status: 'Stokta'
        };

        try {
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await res.json();

            if (res.ok && result.success) {
                statusDiv.innerText = "Başarıyla Kaydedildi!";
                statusDiv.className = "status-msg text-success";
                btnSave.innerText = "Tamamlandı";
            } else {
                throw new Error(result.error || "Sunucu hatası");
            }

        } catch (error) {
            statusDiv.innerText = "Hata: " + error.message;
            statusDiv.className = "status-msg text-error";
            btnSave.disabled = false;
            btnSave.innerText = "Tekrar Dene";
        }
    });
});
