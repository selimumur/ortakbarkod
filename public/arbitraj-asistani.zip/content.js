// content.js - Injected into the page

// Helper to get React State from Trendyol
function getTrendyolData() {
    try {
        if (window.__PRODUCT_DETAIL_APP_INITIAL_STATE__) {
            const product = window.__PRODUCT_DETAIL_APP_INITIAL_STATE__.product;
            return {
                title: product.name,
                price: product.price.sellingPrice.value,
                image: product.images[0],
                market: 'Trendyol'
            };
        }
    } catch (e) { console.log('Trendyol state not found', e); }
    return null;
}

// Helper for Hepsiburada
function getHepsiburadaData() {
    try {
        // Hepsiburada often has JSON-LD
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (let s of scripts) {
            const json = JSON.parse(s.innerText);
            if (json['@type'] === 'Product' || json['@type'] === 'Offer') {
                const offer = json.offers || json;
                const price = offer.price || offer.lowPrice || offer.highPrice;
                return {
                    title: json.name,
                    price: parseFloat(price),
                    image: json.image,
                    market: 'Hepsiburada'
                };
            }
        }
    } catch (e) { console.log('HB json parse error', e); }
    return null;
}

// Fallback Generic Scraper
function getGenericData() {
    const title = document.querySelector('meta[property="og:title"]')?.content || document.title;
    const image = document.querySelector('meta[property="og:image"]')?.content;
    const siteName = document.querySelector('meta[property="og:site_name"]')?.content || window.location.hostname;

    // Attempt price finding
    let price = 0;
    const priceMeta = document.querySelector('meta[property="og:price:amount"]')?.content ||
        document.querySelector('meta[property="product:price:amount"]')?.content;

    if (priceMeta) price = parseFloat(priceMeta);

    // If no price, try regex on body text (Client side is fast enough)
    if (!price) {
        // Naive text search on visible elements?
        // For now, let's trust the user or let them edit in popup.
    }

    return { title, price, image, market: siteName };
}

// Main Extractor
function extractProductDetails() {
    let data = null;
    const host = window.location.hostname;

    if (host.includes('trendyol')) data = getTrendyolData();
    else if (host.includes('hepsiburada')) data = getHepsiburadaData();

    // Fallback if specific failed or not matched
    if (!data || !data.title) {
        data = getGenericData();
    }

    // Final Polish
    if (data) {
        data.url = window.location.href;
        if (!data.market) {
            if (host.includes('trendyol')) data.market = 'Trendyol';
            else if (host.includes('amazon')) data.market = 'Amazon';
            else if (host.includes('hepsiburada')) data.market = 'Hepsiburada';
        }
    }

    return data;
}

// Listen for messages from Popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_DETAILS") {
        const details = extractProductDetails();
        sendResponse(details);
    }
});
